"""
业务公共错误码
"""
from enum import Enum


class ErrorCode(Enum):
    SUCCESS = 0
    FAILURE = 1
