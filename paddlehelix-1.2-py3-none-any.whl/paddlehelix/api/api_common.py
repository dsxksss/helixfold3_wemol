"""
通用API调用，例如查询任务执行结果
"""

from typing import Any

import requests

from .auth import APIAuthUtil
from .code import ErrorCode
from .config import HOST, SCHEME
from .config import SINGLE_SUBMIT_MODE, BATCH_SUBMIT_MODE
from .registry import ServerAPIRegistry
from .structures import QueryTaskInfoResponse, QueryTaskPriceResponse, CancelTaskResponse
from .task import TaskUtil
from ..utils import file_util
from ..version.structures import list_type, dict_type


class CommonClient:
    def __init__(self, ak: str = "", sk: str = ""):
        self._ak = ak
        self._sk = sk
        self.__authClient = APIAuthUtil(ak, sk)

    def cancel_task(self, task_id: int = 0, **kwargs) -> CancelTaskResponse:
        """
        取消任务
        :param task_id: 任务ID
        """
        if task_id <= 0:
            raise f"The parameter task_id {task_id} is not valid."
        response = requests.post("".join([SCHEME, HOST, ServerAPIRegistry.Common.cancel_task.uri]),
                                 headers=self.__authClient.generate_header(ServerAPIRegistry.Common.cancel_task.uri),
                                 json={"task_id": task_id})
        if response.status_code == 200:
            resp_json = response.json()
            if resp_json.get("code") == ErrorCode.SUCCESS.value:
                return CancelTaskResponse(code=ErrorCode.SUCCESS.value, msg=resp_json.get("msg", ""))
            else:
                return CancelTaskResponse(code=ErrorCode.FAILURE.value, msg=resp_json.get("msg", ""))
        return CancelTaskResponse(code=ErrorCode.FAILURE.value, msg="")

    # def batch_cancel_task(self, task_ids: list = None, **kwargs):
    #     """
    #     批量取消任务
    #     :param task_ids: 任务ID列表
    #     """
    #     if task_ids is None or len(task_ids) <= 0:
    #         return
    #     for task_id in task_ids:
    #         requests.post("".join([SCHEME, HOST, ServerAPIRegistry.Common.cancel_task.uri]),
    #                       headers=self.__authClient.generate_header(ServerAPIRegistry.Common.cancel_task.uri),
    #                       json={"task_id": task_id})

    def query_task_info(self, task_id: int = 0, **kwargs) -> QueryTaskInfoResponse:
        """
        HelixFold3查询任务处理结果API
        :param task_id: 任务ID
        :return:
            examples:
                {
                    "code": 0,
                    "msg": "",
                    "data": {
                        "status": 10, # 2 -> 运行中，1 -> 完成，-1 -> 失败
                        "run_time", 10,
                        "result": "{"download_url":"https://"}"
                    }
                }
        """
        if task_id <= 0:
            return QueryTaskInfoResponse(code=ErrorCode.FAILURE.value, msg="", data=None)
        response = requests.post("".join([SCHEME, HOST, ServerAPIRegistry.Common.query_task_info.uri]),
                                 headers=self.__authClient.generate_header(
                                     ServerAPIRegistry.Common.query_task_info.uri),
                                 json={"task_id": task_id})
        if response.status_code == 200:
            resp_json = response.json()
            if resp_json.get("code") == ErrorCode.SUCCESS.value:
                return QueryTaskInfoResponse(code=ErrorCode.SUCCESS.value,
                                             msg=resp_json.get("msg", ""),
                                             data=resp_json.get("data", None)
                                             )
        return QueryTaskInfoResponse(code=ErrorCode.FAILURE.value, msg="", data=None)

    def query_task_infos(self, task_ids: list_type[int] = None, **kwargs) -> list_type[QueryTaskInfoResponse]:
        """
        HelixFold3批量查询任务处理结果API
        :param task_ids: 任务ID列表
        :return:
            examples:
                [
                    {
                        "code": 0,
                        "msg": "",
                        "data": {
                            "status": 10, # 10:运行中，20:取消，30:完成，40:失败
                            "run_time", 10,
                            "result": "{"download_url":"https://"}"
                        }
                    }
                ]
        """
        res = []
        if task_ids is None or len(task_ids) <= 0:
            return res
        for task_id in task_ids:
            response = requests.post("".join([SCHEME, HOST, ServerAPIRegistry.Common.query_task_info.uri]),
                                     headers=self.__authClient.generate_header(
                                         ServerAPIRegistry.Common.query_task_info.uri),
                                     json={"task_id": task_id})
            if response.status_code == 200:
                resp_json = response.json()
                if resp_json.get("code") == ErrorCode.SUCCESS.value:
                    res.append(QueryTaskInfoResponse(
                        code=ErrorCode.SUCCESS.value,
                        msg=resp_json.get("msg", ""),
                        data=resp_json.get("data", None)))
                else:
                    res.append(QueryTaskInfoResponse(code=ErrorCode.FAILURE.value, msg="", data=None))
        return res

    def download_task_result(self, save_dir: str, task_id: int) -> str:
        """
        下载任务结果
        :param save_dir: 保存目录
        :param task_id: 任务ID
        :return: 文件保存目录 download_dir + '/' + task_id
        """
        try:
            file_util.create_directories(save_dir)
        except RuntimeError:
            return ""
        task_info = self.query_task_info(task_id)
        if task_info.code != ErrorCode.SUCCESS.value:
            return ""
        file_util.clear_dir(save_dir)
        download_url = task_info.data.get_download_url()
        if len(download_url) > 0:
            file_util.download_file(save_dir, file_util.parse_filename_from_url(download_url), download_url)
        return save_dir

    def download_task_results(self, save_dir: str, task_ids: list_type[int]) -> list_type[str]:
        """
        批量下载任务结果
        :param save_dir: 保存目录
        :param task_ids: 任务ID列表
        :return: 文件保存目录列表，对于每个task的结果文件，保存目录为 download_dir + '/' + task_id
        """
        res = []
        for task_id in task_ids:
            res.append(self.download_task_result(save_dir, task_id))
        return res

    def query_task_prices(self,
                          data: dict_type[str, Any] = None,
                          data_list: list_type[dict_type[str, Any]] = None,
                          **kwargs) -> list_type[QueryTaskPriceResponse]:
        task_name = kwargs.get("task_name")
        mode = kwargs.get("mode")
        # check common param
        assert isinstance(task_name, str), "The parameter task_name is not of str type."
        assert isinstance(mode, str), "The parameter mode is not of str type."
        if task_name != ServerAPIRegistry.HelixFold3.name:
            raise f"The parameter task_name {task_name} is not supported."
        if mode != SINGLE_SUBMIT_MODE and mode != BATCH_SUBMIT_MODE:
            raise f"The parameter mode {mode} is not supported."
        # check task param
        task_list = TaskUtil.parse_task_data_list_from_all_kinds_input(data, data_list, **kwargs)
        if len(task_list) <= 0:
            raise f"The task data is empty."
        # query task price
        res = []
        if mode == SINGLE_SUBMIT_MODE:
            uri = ServerAPIRegistry.HelixFold3.submit.uri + "/price"
            for task in task_list:
                response = requests.post("".join([SCHEME, HOST, uri]),
                                         headers=self.__authClient.generate_header(uri),
                                         json=task.data)
                if response.status_code == 200:
                    resp_json = response.json()
                    if resp_json.get("code") == ErrorCode.SUCCESS.value:
                        res.append(QueryTaskPriceResponse(
                            code=ErrorCode.SUCCESS.value,
                            msg=resp_json.get("msg", ""),
                            data=resp_json.get("data", None)))
                    else:
                        res.append(QueryTaskPriceResponse(code=ErrorCode.FAILURE.value, msg=resp_json.get("msg", "")))
                    continue
                res.append(QueryTaskInfoResponse(code=ErrorCode.FAILURE.value, msg="", data=None))
            return res
        elif mode == BATCH_SUBMIT_MODE:
            uri = ServerAPIRegistry.HelixFold3.batch_submit.uri + "/price"
            data_list = []
            for task in task_list:
                data_list.append(task.data)
            json_data = {
                "tasks": data_list
            }
            response = requests.post("".join([SCHEME, HOST, uri]),
                                     headers=self.__authClient.generate_header(uri),
                                     json=json_data)
            if response.status_code == 200:
                resp_json = response.json()
                if resp_json.get("code") == ErrorCode.SUCCESS.value:
                    res.append(QueryTaskPriceResponse(
                        code=ErrorCode.SUCCESS.value,
                        msg=resp_json.get("msg", ""),
                        data=resp_json.get("data", None)))
                else:
                    res.append(QueryTaskPriceResponse(code=ErrorCode.FAILURE.value, msg=resp_json.get("msg", "")))
                return res
            res.append(QueryTaskInfoResponse(code=ErrorCode.FAILURE.value, msg="", data=None))
            return res
        return res
