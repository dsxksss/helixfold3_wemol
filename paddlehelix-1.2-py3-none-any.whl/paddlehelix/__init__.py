"""
设置sdk package导入初始化逻辑
"""

import os
import sys


# 初始化项目目录及其环境变量
project_root_path = os.path.dirname(os.path.abspath(__file__))
sys.path.append(project_root_path)
os.environ['PROJECT_ROOT'] = project_root_path

