import os
import setuptools

setuptools.setup(
    name='paddlehelix',
    version='1.2',
    description='PaddleHelix API 客户端',
    packages=setuptools.find_packages(),
    author='lilong19',
    author_email='lilong19@baidu.com',
)
